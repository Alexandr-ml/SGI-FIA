/*
  SGI-FIA - Script de servicios web Firebase/Firestore

  Uso:
  1. Abrir este archivo desde una pagina HTML con type="module", o ejecutarlo en
     un entorno que permita imports HTTPS de ES modules.
  2. Verificar que las reglas de Firestore permitan escritura al proyecto pdm-ues.
  3. Ejecutar seedInitialEquipment() para crear/actualizar los equipos base.

  La app web y la app movil usan estas mismas colecciones en Firebase.
*/

import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-app.js";
import {
  collection,
  doc,
  getDocs,
  getFirestore,
  query,
  serverTimestamp,
  setDoc,
} from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";

export const firebaseConfig = {
  apiKey: "AIzaSyBxGl-iCfD8e-RcKwQOS32NO4w01PjIzis",
  authDomain: "pdm-ues.firebaseapp.com",
  projectId: "pdm-ues",
  storageBucket: "pdm-ues.firebasestorage.app",
  messagingSenderId: "607923927954",
  appId: "1:607923927954:web:b597bfe53ceb2d5ca41f4b",
  measurementId: "G-FV4TZQ8NVP",
};

export const collections = {
  documentos: "documentos",
  equipos: "equipos_informaticos",
  prestatarios: "prestatarios",
  prestamos: "prestamos",
  prestamosTesis: "prestamos_tesis",
  prestamosEquipoHoras: "prestamos_equipo_horas",
  prestamosEquipoRecurrente: "prestamos_equipo_recurrente",
  devoluciones: "devoluciones",
  devolucionesTesis: "devoluciones_tesis",
  levantamientos: "levantamientos_fisicos",
};

export const schema = {
  documentos: ["titulo", "tipo", "isbn", "idioma", "anio", "ejemplares", "createdAt", "updatedAt"],
  equipos_informaticos: [
    "nombre",
    "numero_serie",
    "marca",
    "modelo",
    "ubicacion",
    "costo_unidad",
    "unidades",
    "descripcion",
    "estado_funcional",
    "estado_prestamo",
    "fecha_ultimo_levantamiento",
    "createdAt",
    "updatedAt",
  ],
  prestatarios: ["carnet", "nombre", "updatedAt"],
  prestamos: [
    "carnet_prestatario",
    "nombre_prestatario",
    "id_documento",
    "titulo_documento",
    "fecha_prestamo",
    "fecha_limite",
    "estado",
    "createdAt",
    "updatedAt",
  ],
  prestamos_tesis: [
    "nombre_prestatario",
    "carnet_prestatario",
    "codigo_tesis",
    "titulo_tesis",
    "fecha_prestamo",
    "fecha_devolucion",
    "estado_prestamo",
    "observaciones",
    "createdAt",
    "updatedAt",
  ],
  prestamos_equipo_horas: [
    "nombre_prestatario",
    "carnet_prestatario",
    "equipo",
    "equipos_ids",
    "fecha_prestamo",
    "hora_inicio",
    "hora_fin",
    "actividad",
    "estado_prestamo",
    "observaciones",
    "createdAt",
    "updatedAt",
  ],
  prestamos_equipo_recurrente: [
    "nombre_prestatario",
    "carnet_prestatario",
    "equipo",
    "equipos_ids",
    "fecha_inicio",
    "fecha_fin",
    "estado_prestamo",
    "observaciones",
    "createdAt",
    "updatedAt",
  ],
  devoluciones: ["id_prestamo", "tipo_prestamo", "marcar_devuelto", "fecha_devolucion", "createdAt", "updatedAt"],
  devoluciones_tesis: [
    "id_prestamo",
    "titulo_tesis",
    "marcar_devuelto",
    "fecha_devolucion",
    "createdAt",
    "updatedAt",
  ],
  levantamientos_fisicos: ["fecha_levantamiento", "numero_serie", "observaciones", "createdAt", "updatedAt"],
};

const initialEquipos = [
  {
    id: "eq-monitor-dell",
    nombre: "Monitor Dell",
    numero_serie: "MON-001",
    marca: "Dell",
    modelo: "S2725HSM",
    ubicacion: "Centro de Computo",
    costo_unidad: 0,
    unidades: 1,
    descripcion: "Monitor para estaciones de trabajo",
    estado_funcional: "Activo",
    estado_prestamo: "Disponible",
  },
  {
    id: "eq-impresora-hp",
    nombre: "Impresora HP",
    numero_serie: "IMP-001",
    marca: "HP",
    modelo: "Smart Tank 580",
    ubicacion: "Secretaria de Facultad",
    costo_unidad: 0,
    unidades: 1,
    descripcion: "Impresora multifuncional",
    estado_funcional: "Activo",
    estado_prestamo: "Disponible",
  },
  {
    id: "eq-laptop-dell-x985",
    nombre: "Laptop Dell x985",
    numero_serie: "LAP-985",
    marca: "Dell",
    modelo: "x985",
    ubicacion: "Unidad de Ciencias Basicas",
    costo_unidad: 0,
    unidades: 1,
    descripcion: "Laptop asignada a unidad academica",
    estado_funcional: "Activo",
    estado_prestamo: "Disponible",
  },
  {
    id: "eq-proyector-spectra-q891",
    nombre: "Proyector Spectra Q891",
    numero_serie: "PRO-891",
    marca: "Spectra",
    modelo: "Q891",
    ubicacion: "Edificio B - Nivel 1 - FIA",
    costo_unidad: 0,
    unidades: 1,
    descripcion: "Proyector para aulas",
    estado_funcional: "Activo",
    estado_prestamo: "Disponible",
  },
];

export function getDb() {
  const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
  return getFirestore(app);
}

export async function seedInitialEquipment() {
  const db = getDb();
  await Promise.all(
    initialEquipos.map(({ id, ...equipo }) =>
      setDoc(
        doc(db, collections.equipos, id),
        {
          ...equipo,
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      ),
    ),
  );
}

export async function countCollections() {
  const db = getDb();
  const entries = await Promise.all(
    Object.values(collections).map(async (name) => {
      const snapshot = await getDocs(query(collection(db, name)));
      return [name, snapshot.size];
    }),
  );
  return Object.fromEntries(entries);
}
