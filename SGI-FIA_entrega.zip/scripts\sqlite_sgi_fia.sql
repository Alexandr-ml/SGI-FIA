-- SGI-FIA - Script SQLite historico/local
-- La version actual de la app usa Firebase/Firestore como base principal.
-- Este script conserva la estructura equivalente para SQLite local.

PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS devoluciones_tesis;
DROP TABLE IF EXISTS devoluciones;
DROP TABLE IF EXISTS prestamos_equipo_recurrente;
DROP TABLE IF EXISTS prestamos_equipo_horas;
DROP TABLE IF EXISTS prestamos_tesis;
DROP TABLE IF EXISTS prestamos;
DROP TABLE IF EXISTS levantamientos_fisicos;
DROP TABLE IF EXISTS prestatarios;
DROP TABLE IF EXISTS equipos_informaticos;
DROP TABLE IF EXISTS documentos;

CREATE TABLE documentos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('Libro', 'Tesis')),
  isbn TEXT DEFAULT '',
  idioma TEXT DEFAULT '',
  anio INTEGER DEFAULT 0,
  ejemplares INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipos_informaticos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  numero_serie TEXT NOT NULL UNIQUE,
  marca TEXT NOT NULL,
  modelo TEXT NOT NULL,
  ubicacion TEXT DEFAULT '',
  costo_unidad REAL DEFAULT 0,
  unidades INTEGER DEFAULT 1,
  descripcion TEXT DEFAULT '',
  estado_funcional TEXT DEFAULT 'Activo',
  estado_prestamo TEXT DEFAULT 'Disponible',
  fecha_ultimo_levantamiento TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE prestatarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  carnet TEXT UNIQUE,
  nombre TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE prestamos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  carnet_prestatario TEXT DEFAULT 'N/A',
  nombre_prestatario TEXT NOT NULL,
  id_documento INTEGER,
  titulo_documento TEXT NOT NULL,
  fecha_prestamo TEXT NOT NULL,
  fecha_limite TEXT NOT NULL,
  estado TEXT DEFAULT 'Pendiente',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_documento) REFERENCES documentos(id)
);

CREATE TABLE prestamos_tesis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre_prestatario TEXT NOT NULL,
  carnet_prestatario TEXT DEFAULT 'N/A',
  codigo_tesis TEXT DEFAULT 'Automatico',
  titulo_tesis TEXT NOT NULL,
  fecha_prestamo TEXT NOT NULL,
  fecha_devolucion TEXT NOT NULL,
  estado_prestamo TEXT DEFAULT 'Pendiente',
  observaciones TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE prestamos_equipo_horas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre_prestatario TEXT NOT NULL,
  carnet_prestatario TEXT DEFAULT 'N/A',
  equipo TEXT NOT NULL,
  equipos_ids TEXT DEFAULT '[]',
  fecha_prestamo TEXT NOT NULL,
  hora_inicio TEXT NOT NULL,
  hora_fin TEXT NOT NULL,
  actividad TEXT DEFAULT 'Prestamo por horas',
  estado_prestamo TEXT DEFAULT 'Pendiente',
  observaciones TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE prestamos_equipo_recurrente (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre_prestatario TEXT NOT NULL,
  carnet_prestatario TEXT DEFAULT 'N/A',
  equipo TEXT NOT NULL,
  equipos_ids TEXT DEFAULT '[]',
  fecha_inicio TEXT NOT NULL,
  fecha_fin TEXT NOT NULL,
  estado_prestamo TEXT DEFAULT 'Pendiente',
  observaciones TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE devoluciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_prestamo INTEGER NOT NULL,
  tipo_prestamo TEXT DEFAULT 'Libro',
  marcar_devuelto INTEGER NOT NULL DEFAULT 1,
  fecha_devolucion TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE devoluciones_tesis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_prestamo INTEGER NOT NULL,
  titulo_tesis TEXT NOT NULL,
  marcar_devuelto INTEGER NOT NULL DEFAULT 1,
  fecha_devolucion TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_prestamo) REFERENCES prestamos_tesis(id)
);

CREATE TABLE levantamientos_fisicos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha_levantamiento TEXT NOT NULL,
  numero_serie TEXT DEFAULT '',
  observaciones TEXT DEFAULT 'Auditoria fisica de activos',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_documentos_titulo_tipo ON documentos(titulo, tipo);
CREATE INDEX idx_equipos_numero_serie ON equipos_informaticos(numero_serie);
CREATE INDEX idx_prestamos_estado ON prestamos(estado);
CREATE INDEX idx_prestamos_tesis_estado ON prestamos_tesis(estado_prestamo);
CREATE INDEX idx_levantamientos_fecha ON levantamientos_fisicos(fecha_levantamiento);

INSERT INTO equipos_informaticos (
  nombre, numero_serie, marca, modelo, ubicacion, costo_unidad, unidades,
  descripcion, estado_funcional, estado_prestamo
) VALUES
  ('Monitor Dell', 'MON-001', 'Dell', 'S2725HSM', 'Centro de Computo', 0, 1,
   'Monitor para estaciones de trabajo', 'Activo', 'Disponible'),
  ('Impresora HP', 'IMP-001', 'HP', 'Smart Tank 580', 'Secretaria de Facultad', 0, 1,
   'Impresora multifuncional', 'Activo', 'Disponible'),
  ('Laptop Dell x985', 'LAP-985', 'Dell', 'x985', 'Unidad de Ciencias Basicas', 0, 1,
   'Laptop asignada a unidad academica', 'Activo', 'Disponible'),
  ('Proyector Spectra Q891', 'PRO-891', 'Spectra', 'Q891', 'Edificio B - Nivel 1 - FIA', 0, 1,
   'Proyector para aulas', 'Activo', 'Disponible');
